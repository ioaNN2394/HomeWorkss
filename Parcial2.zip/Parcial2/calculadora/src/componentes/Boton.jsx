import React from 'react';

export default function Boton({ label, onClick }) {
  return (
    <button className="boton" onClick={() => onClick(label)}>
      {label}
    </button>
  );
}
