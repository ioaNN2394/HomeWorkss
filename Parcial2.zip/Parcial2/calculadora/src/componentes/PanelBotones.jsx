import React from 'react';
import Boton from './Boton';

const botones = [
  ['7', '4', '1', '0'],
  ['8', '5', '2', '*'],
  ['9', '6', '3', '-'],
  ['/', '.', '=', '+'],
  ['C'] 
];

export default function PanelBotones({ onClick }) {
  return (
    <div className="panel-botones">
      {botones.map((fila, filaIndex) => (
        <div key={filaIndex} className="fila-botones">
          {fila.map((btn) => (
            <Boton key={btn} label={btn} onClick={onClick} />
          ))}
        </div>
      ))}
    </div>
  );
}
