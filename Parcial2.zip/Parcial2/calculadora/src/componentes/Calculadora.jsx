import React from 'react';
import Panel from './Panel';
import PanelBotones from './PanelBotones';
import useCalculadora from '../hooks/useCalculadora';
import './Calculadora.css';


export default function Calculadora() {
  const { displayValue, handleButtonClick } = useCalculadora();

  return (
    <div className="calculadora">
      <Panel value={displayValue} /> 
      <PanelBotones onClick={handleButtonClick} /> 
    </div>
  );
}
