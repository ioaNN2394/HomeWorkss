import React from 'react';

export default function Panel({ value }) {
  return (
    <div className="panel">
      <h1>{value}</h1> 
    </div>
  );
}
