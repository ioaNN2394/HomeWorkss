import { useState } from 'react';

export default function useCalculadora() {
  const [displayValue, setDisplayValue] = useState(''); 
  const [waitingForOperand, setWaitingForOperand] = useState(false); 

  // Maneja los clics en los botones
  const handleButtonClick = (label) => {
    if (!isNaN(label) || label === '.') {
      handleNumber(label); 
    } else if (['+', '-', '*', '/'].includes(label)) {
      handleOperator(label); 
    } else if (label === '=') {
      handleEqual(); 
    } else if (label === 'C') {
      handleClear(); 
    }
  };

  // Maneja la entrada de números
  const handleNumber = (num) => {
    if (waitingForOperand) {
      setDisplayValue(displayValue + num); 
      setWaitingForOperand(false);
    } else {
      setDisplayValue(displayValue === '' ? num : displayValue + num); 
    }
  };

  // Maneja la entrada de operadores
  const handleOperator = (nextOperator) => {
    if (!waitingForOperand) {
      setDisplayValue(displayValue + ' ' + nextOperator + ' '); 
      setWaitingForOperand(true); 
    }
  };

  // Calcula el resultado cuando se presiona igual
  const handleEqual = () => {
    try {
      const result = eval(displayValue); 
      setDisplayValue(String(result)); 
    } catch (error) {
      setDisplayValue('Error'); 
    }
  };

  // Añade un punto decimal
  const handleDecimal = () => {
    if (!displayValue.includes('.')) {
      setDisplayValue(displayValue + '.'); 
    }
  };

  // Limpia la pantalla
  const handleClear = () => {
    setDisplayValue(''); 
    setWaitingForOperand(false); 
  };

  return {
    displayValue, 
    handleButtonClick, 
  };
}
