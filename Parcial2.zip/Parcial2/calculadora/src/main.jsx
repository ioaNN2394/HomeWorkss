import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import Calculadora from './componentes/Calculadora'
import './index.css'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Calculadora />
  </StrictMode>,
)
